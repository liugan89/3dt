package com.haphest.a3dtracking.output;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.haphest.a3dtracking.R;

public class OutputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_output);
    }
}
