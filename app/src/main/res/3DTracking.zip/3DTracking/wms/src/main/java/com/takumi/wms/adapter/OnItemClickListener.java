package com.takumi.wms.adapter;

public interface OnItemClickListener {
    void onItemClick(int position);
}
