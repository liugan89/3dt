package com.takumi.wms.adapter;

public interface RVItemClick {

    void itemClick(int position);
}
