package com.takumi.wms.adapter;

public interface RVItemItemClick {

    void itemClick(int p1, int p2);
}
