package com.takumi.wms.adapter.expand;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by hbh on 2017/4/20.
 */

public class BaseViewHolder extends RecyclerView.ViewHolder {
    public BaseViewHolder(View itemView) {
        super(itemView);
    }
}
