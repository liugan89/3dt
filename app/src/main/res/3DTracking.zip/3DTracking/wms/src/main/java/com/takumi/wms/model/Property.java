package com.takumi.wms.model;

public class Property {
    private String key;
    private String defaultValue;
    private String realValue;
}
