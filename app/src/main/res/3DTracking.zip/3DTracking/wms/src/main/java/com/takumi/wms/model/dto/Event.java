package com.takumi.wms.model.dto;

public interface Event {
}
