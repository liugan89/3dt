package com.takumi.wms.widget;

public interface LotOKListener {
    void lotOK();
}
