package com.google.zxing.client.android;

/**
 * Created by yangxixi on 16/11/21.
 */

public class Ids {
    public static final int decode = 1001;
    public static final int decode_failed = 1002;
    public static final int decode_succeeded = 1003;
    public static final int launch_product_query = 1004;
    public static final int quit = 1005;
    public static final int restart_preview = 1006;
    public static final int return_scan_result = 1007;
}
